//
//  Node.cpp
//  lab2
//
//  Created by Alexandra Greenwood on 12/3/17.
//  Copyright © 2017 Alexandra Hurst. All rights reserved.
//

#include "Node.h"
