//
//  main.cpp
//  lab2.cpp
//
//  Created by Alexandra Greenwood on 9/24/17.
//  Copyright © 2017 Alexandra Hurst. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <typeinfo>
#include <vector>
#include <array>
#include "readin.h"
#include "tokens.h"
#include "parser.h"
#include "predicate.h"
#include "parameter.h"
#include "rule.h"
#include "datalogue.h"
#include "scheme.h"
#include "tuple.h"
#include "Relation.h"
#include "Database.h"


int main(int argc, char* argv[]) {
    std::string filename=argv[1];
        Readin parsing=Readin(filename);
        parsing.analysis();
        std::stringstream output;
        std::vector<Token> tokenvect= parsing.getTokens();
        
        try{
            Parser p=Parser(tokenvect);
            Datalogue d= p.getData();
            Database data;
            data.load(d.schemes, d.facts, d.queries);
            //std::cout<<"LOADED"<<std::endl;
            data.runQuery();
            
        }catch(std::string s){
            std::cout<<"FAILURE"<<std::endl;
        }
    
    // insert code here...
    /*std::string filename=argv[1];
    Readin lex= Readin(filename);
    lex.analysis();
    std::vector<Token>tokens= lex.getTokens();
    std::stringstream output;
    try{
            Parser parsing = Parser(tokens);
            //std::cout<<i<<std::endl;
            Datalogue alexandra=parsing.getData();
            output<<alexandra.toString();
            std::cout<<"Success!"<<std::endl;
            std::cout<<output.str();
        }catch(std::string c){
            //std::cout<<"Failure!"<<std::endl;
            //std::cout<<"\t c"<<std::endl;
        }*/
    
    return 0;
}
