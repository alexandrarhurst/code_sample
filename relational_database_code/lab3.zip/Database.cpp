//
//  Database.cpp
//  lab2
//
//  Created by Alexandra Greenwood on 10/21/17.
//  Copyright © 2017 Alexandra Hurst. All rights reserved.
//

#include "Database.h"


void Database::addRelation(Relation r){
    //std::cout<<r.getName()<<std::endl;
    m.insert(std::pair<std::string, Relation>(r.getName(), r));
}

void Database::load(std::vector<Predicate> i, std::vector<Predicate> j, std::vector<Predicate> k){
    //std::cout<<"LOADING"<<std::endl;
    schemes=i;
    facts=j;
    queries=k;
    
    for(int u=0; u<schemes.size(); u++){
        Relation r;
        std::string temp=i[u].getID();
        std::vector<Parameter> othertemp=i[u].getParams();
        Scheme brexlyn;
        brexlyn.addParams(othertemp);
        r.setName(temp);
        r.setScheme(brexlyn);
        addRelation(r);
        
    }
    //std::cout<<"UNO"<<std::endl;
    for(int u=0; u<j.size(); u++){
        //these variables shall be named after bad utah names
        Tuple tee;
        std::string fingname=j[u].getID();
        std::vector<Parameter> fingparams=j[u].getParams();
        std::vector<std::string> fingstrings;
        for(int v=0; v<fingparams.size(); v++){
            std::string ainzlee=fingparams[v].getValue();
            //std::cout<<ainzlee<<std::endl;
            fingstrings.push_back(ainzlee);
        }
        tee.list=fingstrings;
        tee.setName(fingname);
        addToRelation(tee);
    }
}

void Database::printRelations(){
    //but do I really need this?
}

void Database::addToRelation(Tuple t){
    std::string currentname=t.getName();
    //std::cout<<"B"<<t.getName()<<std::endl;
    Relation current = m.find(currentname)->second;
    current.addTuple(t);
    m.at(currentname)=current;
}

std::string Database::toString(){
    //do I need a "to print" array?
    return "";
}

void Database::runQuery(){
    Relation r;
    //std::cout<<"RUN QUERY"<<std::endl;
    //each query
    for(int i=0; i<queries.size(); i++){
        std::string zella=queries[i].getID();
        std::vector<Parameter> p=queries[i].getParams();
        Relation tempy=(m.find(zella))->second;
        r=tempy;
        //number of variables in the scheme.
        for(int j=0; j<p.size(); j++){
            //std::cout<<j<<" "<<p[j].getType()<<std::endl;
            bool dups=false;
            int possy=0;
            if(p[j].getType()=="STRING"){
                //std::cout<<p[j].getValue()<<std::endl;
                tempy=tempy.select(j,p[j].getValue());
            }else if(p[j].getType()=="ID"){
                //std::cout<<"W "<<p[j].getValue()<<" "<<ids.size()<<std::endl;
                for(int k=0; k<ids.size(); k++){
                    //std::cout<<"A"<<p[j].getValue()<<" "<<ids[k]<<std::endl;
                    if(ids[k]==p[j].getValue()){
                        //std::cout<<"HI"<<std::endl;
                        dups=true;
                        possy=k;
                    }
                }
                
                if(dups==true){
                    //std::cout<<"HI"<<possy<<" "<<j<<std::endl;
                    tempy=tempy.select(possy, j);
                }else{
                    //std::cout<<p[j].getValue()<<std::endl;
                    ids.push_back(p[j].getValue());
                    pos.push_back(j);
                }
            }
        }
    
        //this is my leave off point from saturday.
        tempy=tempy.project(pos);
        tempy=tempy.rename(ids);
        //std::cout<<"B"<<std::endl;
        
        std::stringstream ss;
        for(int j=0; j<p.size(); j++){
            ss<<p[j].getValue();
            if(j<(p.size()-1)){
                ss<<",";
            }
            //std::cout<<p[j].getValue()<<std::endl;
        }
        int num=tempy.countTuples(pos,ids);
        std::cout<<zella<<"("<<ss.str()<<")? ";
        if(tempy.data.size()>0) {
            std::cout<<"Yes("<<num<<")"<<std::endl;
            tempy.printTuples(pos, ids,num);
        }else{
            std::cout<<"No"<<std::endl;
        }
        
        ids.clear();
        pos.clear();
    }
}


