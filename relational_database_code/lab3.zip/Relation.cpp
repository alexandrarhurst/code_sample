//
//  Relation.cpp
//  lab2
//
//  Created by Alexandra Greenwood on 10/21/17.
//  Copyright © 2017 Alexandra Hurst. All rights reserved.
//

#include "Relation.h"

std::string Relation::getName(){
    return name;
}

void Relation::setName(std::string s){
    name=s;
}

void Relation::addTuple(Tuple t){
    data.insert(t);
}

Scheme Relation::getScheme(){
    return scheme2;
}

void Relation::setScheme(Scheme s){
    scheme2=s;
}

Relation Relation::select(int i, std::string s){
    //std::cout<<"SELECT1"<<std::endl;
    Relation rel;
    rel.name=name;
    rel.scheme2=scheme2;
    Tuple tee;
    for(std::set<Tuple>::iterator iter=data.begin(); iter!=data.end(); iter++){
        tee= *iter;
        if(tee.list[i]==s){
            rel.addTuple(tee);
        }
        
    }
    return rel;
}

Relation Relation::select(int i, int j){
    //std::cout<<"SELECT2"<<std::endl;
    Relation rel;
    rel.name=name;
    rel.scheme2=scheme2;
    Tuple tee;
    for(std::set<Tuple>::iterator iter=data.begin(); iter!=data.end(); iter++){
        tee= *iter;
        if(tee.list[i]==tee.list[j]){
            rel.addTuple(tee);
        }
    }
    return rel;
}

Relation Relation::project(std::vector<int> p){
    Relation r;
    r.name=name;
    r.scheme2=scheme2;
    Tuple proj;
    int projint;
    int j=0;
    
    for(std::set<Tuple>::iterator iter=data.begin(); iter!=data.end(); iter++){
        //std::cout<<"PROJECT"<<std::endl;
        j=1;
        Tuple temp;
        temp= *iter;
        for(int i=0; i<p.size(); i++){
            projint=p[i];
            //std::cout<<temp.list[projint]<<std::endl;
            proj.list.push_back(temp.list[projint]);
        }
    }
    if(j==1){
        r.data.insert(proj);
    }
    return r;
}

Relation Relation::rename(std::vector<std::string> input){
    //std::cout<<"RENAME"<<std::endl;
    Relation r;
    r.name=name;
    r.data=data;
    r.scheme2.setParams(input);
    return r;
}

int Relation::countTuples(std::vector<int> pos, std::vector<std::string> ids){
    int count=0;
    for(std::set<Tuple>::iterator iter=data.begin(); iter!=data.end(); iter++){
        Tuple temp= *iter;
        std::stringstream ss;
        for(int i=0; i<temp.list.size(); i++){
            count++;
        }
    }
    if(count>0) {
        return count/ids.size();
    }else{
        return 1;
    }
}

void Relation::printTuples(std::vector<int> pos, std::vector<std::string> ids, int num){
    //std::stringstream ss;
    for(std::set<Tuple>::iterator iter=data.begin(); iter !=data.end(); iter++){
        //int i=ite
        Tuple temp=*iter;
        int s=ids.size();
        //std::cout<<s<<std::endl;
        for(int i=0; i<temp.list.size(); i++){
            if(i%s==0){
                std::cout<<"  ";
            }
            std::cout<<ids[i%pos.size()] <<"="<<temp.list[i];
            if((i+1)%s==0){
                std::cout<<"\n";
            }else{
                std::cout<<", ";
            }
            //std::cout<<ids[(i+1)%pos.size()]<<"="<<temp.list[i+1]<<std::endl;
        }
    }
}
