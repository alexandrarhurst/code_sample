//
//  parameter.cpp
//  lab1.cpp
//
//  Created by Alexandra Greenwood on 9/28/17.
//  Copyright © 2017 Alexandra Hurst. All rights reserved.
//

#include "parameter.h"

std::string Parameter::getValue(){
    return value;
}

std::string Parameter::getType(){
    return type;
}
