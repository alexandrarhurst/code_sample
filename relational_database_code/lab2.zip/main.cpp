//
//  main.cpp
//  lab2.cpp
//
//  Created by Alexandra Greenwood on 9/24/17.
//  Copyright © 2017 Alexandra Hurst. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <typeinfo>
#include <vector>
#include "readin.h"
#include "tokens.h"
#include "parser.h"
#include "predicate.h"
#include "parameter.h"
#include "rule.h"
#include "datalogue.h"

int main(int argc, char* argv[]) {
    // insert code here...
    //std::string filename=argv[1];
    std::vector<std::string> files={"ex1.txt","ex2.txt", "ex3.txt","ex4.txt","ex5.txt","ex6.txt","ex7.txt","ex8.txt","ex9.txt","ex10.txt"};
    for(int i=0; i<files.size(); i++){
        Readin lex= Readin(files[i]);
        lex.analysis();
        std::vector<Token>tokens= lex.getTokens();
        //std::cout<<tokens.size()<<std::endl;
        //std::cout<<typeid(tokens).name()<<std::endl;
        /*for (int j=0; j<tokens.size() ;j++){
            std::cout<<&tokens[j]<<std::endl;
        }*/
        std::stringstream output;
        try{
            Parser parsing = Parser(tokens);
            //std::cout<<i<<std::endl;
            //Datalogue alexandra=parsing.getData();
            //output<<alexandra.toString();
            std::cout<<"Success!"<<std::endl;
            //std::cout<<output.str();
        }catch(std::string c){
            //std::cout<<"Failure!"<<std::endl;
            //std::cout<<"\t c"<<std::endl;
        }
    }
    /*Readin lex = Readin(filename);
    std::vector<Token> tokens= lex.getTokens();
    for (int i=0; i< tokens.size(); i++){
        std::cout<<tokens[i]->toString() <<std::endl;
    }
    std::cout<<"Total Tokens = "<<tokens.size()<<std::endl;
    std::stringstream output;try{
        Parser parsing(tokens);
        Datalogue alexandra=parsing.getData();
        output<<alexandra.toString();
        std::cout<<"SUCCESS"<<std::endl;
        std::cout<<output.str();
    }catch(std::string c){
        std::cout<<"FAIL"<<std::endl;
    }*/
    return 0;
}
