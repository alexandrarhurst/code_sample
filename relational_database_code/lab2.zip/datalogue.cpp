//
//  datalogue.cpp
//  lab1.cpp
//
//  Created by Alexandra Greenwood on 9/28/17.
//  Copyright © 2017 Alexandra Hurst. All rights reserved.
//

#include "datalogue.h"
#include <iostream>
#include <sstream>


void Datalogue::addScheme(Predicate p){
    schemes.push_back(p);
}

void Datalogue::addFact(Predicate f){
    addDomain(f.getParams());
    facts.push_back(f);
}

void Datalogue::addRule(Rule r){
    addDomain(r.getPred().getParams());
    rules.push_back(r);
}

void Datalogue::addQuery(Predicate q){
    queries.push_back(q);
}

std::string Datalogue::schemes_to_string(){
    std::stringstream out;
    out<<"Schemes(" <<schemes.size()<<"):";
    for(int i=0; i<schemes.size(); i++){
        out<<schemes[i].toString();
    }
    return out.str();
}

std::string Datalogue::facts_to_string(){
    std::stringstream out;
    out<<"Facts(" <<schemes.size()<<"):";
    for(int i=0; i<schemes.size(); i++){
        out<<facts[i].toString();
    }
    return out.str();
}

std::string Datalogue::rules_to_string(){
    std::stringstream out;
    out<<"Rules(" <<schemes.size()<<"):";
    for(int i=0; i<schemes.size(); i++){
        out<<rules[i].toString();
    }
    return out.str();
}

std::string Datalogue::queries_to_string(){
    std::stringstream out;
    out<<"Queries(" <<schemes.size()<<"):";
    for(int i=0; i<schemes.size(); i++){
        out<<queries[i].toString();
    }
    return out.str();
}

std::string Datalogue::toString(){
    std::stringstream out;
    //creat tostrings for everything.
    out<<schemes_to_string()<<std::endl;
    out<<facts_to_string()<<std::endl;
    out<<rules_to_string()<<std::endl;
    out<<queries_to_string()<<std::endl;
    return out.str();
}

void Datalogue::addDomain(std::vector<Parameter> l){
    for(int i=0; i<l.size(); i++){
        if(l[i].getType()=="STRING"){
            d.insert(l[i].getValue());
        }
    }
}
